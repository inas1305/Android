package projetannuel.esgi4moc1.distributorcat;

import android.os.Bundle;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import android.widget.CalendarView;

public class StatsActivity extends AppCompatActivity {

    private static final String API_URL = "http://10.0.2.2:8000" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);


        CalendarView simpleCalendarView = (CalendarView) findViewById(R.id.calendarView); // get the reference of CalendarView
        final long selectedDate = simpleCalendarView.getDate();

        simpleCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                // display the selected date by using a toast

                final Date data = new Date(year-1900,month,dayOfMonth);
                Toast.makeText(getApplicationContext(), dayOfMonth + "/" + month + "/" + year, Toast.LENGTH_LONG).show();
                //System.out.println(data);


                // Create a very simple REST adapter which points the GitHub API.
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl(API_URL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();

                // Create an instance of our GitHub API interface.
                final MyService myService = retrofit.create(MyService.class);

                Thread thread = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try  {
                            // Create a call instance for looking up Retrofit contributors.
                            Call<List<Sensor>> call = myService.sensors();

                            // Fetch and print a list of the Sensor to the library.
                            List<Sensor> sensors = null;
                            try {
                                sensors = call.execute().body();

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            int cpt = 0;
                            for (Sensor sensor : sensors) {

                                SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
                                if(sdf.format(data).equals(sdf.format(sensor.getDate()))){


                                    System.out.println(sensor.getName());
                                    cpt++;


                                }
                                else{
                                    runOnUiThread(new Runnable() {
                                        public void run() {
                                            Toast.makeText(getBaseContext(),"Aucun passage de minou ce jour là !",Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }

                            }
                            System.out.println("Votre chat a mange " + cpt + "fois , le : " + data);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                });
                thread.start();
            }
        });


    }
}